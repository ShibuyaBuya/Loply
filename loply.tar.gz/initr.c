#include <stdlib.h> 
#include <sys/stat.h> 
#include <string.h> 
#include <time.h>
#include <unistd.h>
#include <stdio.h>
size_t defaults;
char filenm[];
int main(int argc, char *argv[]) {
	defaults = 0x3c0;
	strcpy(filenm, "zrun.bin");
/*	if (argc >= 1){
		if (strcmp(argv[1], "-help") == 0) {
        		printf("Usage: %s <file.bin: default zrun.bin> <addr start: default 0x3C0>\n", argv[0]);
			return 1;
		}
	}*/
	printf("%i\n", argc);
	if (argc == 2){
		strcpy(filenm, argv[1]);
	}
	if (argc >= 3){
		strcpy(filenm, argv[1]);
		defaults = strtoull(argv[2], NULL, 16);
	}
	char first_s[4096] = {0};
	FILE *file = fopen(filenm, "rb");
	if (file) {
		fseek(file, defaults, SEEK_SET);
	        fread(first_s, 4096, 1, file);
	        fclose(file);
	} else {
        	perror("Error");
	        return 1;
	}
	printf("0x%zx: %s\n",defaults, first_s);
	return 0;
}
