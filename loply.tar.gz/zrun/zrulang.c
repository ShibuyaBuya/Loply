#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int error = 0;
typedef enum {
    TOKEN_KEYWORD,   // Keywords like PRINT, LOAD, BOOT
    TOKEN_IDENTIFIER, // Identifiers like &var1 or var1
    TOKEN_OPERATOR,   // Operators like eq, lt
    TOKEN_LITERAL,    // String literals, numbers
    TOKEN_PUNCTUATION, // Symbols like {, }, (, )
    TOKEN_INCOMPLETE_LITERAL,
    TOKEN_EOF,         // End of file/input
    TOKEN_NEWLINE,
    TOKEN_ERROR
} TokenType;

typedef struct {
    TokenType type;
    char* value;
} Token;

typedef struct {
    char* source;
    size_t length;
    size_t position;
    int line;
} Lexer;
int count_lines(const char *str) {
    int count = 0;
    while (*str) {
        if (*str == '\n') {
            count++;
        }
        str++;
    }
    // Add 1 to count the last line if the string is not empty
    return count + (*str != '\0' || count == 0);
}

Lexer* create_lexer(char* source) {
    Lexer* lexer = (Lexer*)malloc(sizeof(Lexer));
    lexer->source = source;
    lexer->length = strlen(source);
    lexer->position = 0;
    lexer->line = 1;
    return lexer;
}

void destroy_lexer(Lexer* lexer) {
    if (lexer != NULL){
	    free(lexer);
    }
}

char peek(Lexer* lexer) {
    if (lexer->position >= lexer->length) return '\0';
//    if (lexer->source[lexer->position] == '\n'
    return lexer->source[lexer->position];
}

char advance(Lexer* lexer) {
    if (lexer->position >= lexer->length) return '\0';
    return lexer->source[lexer->position++];
}

Token* create_token(TokenType type, char* value) {
    Token* token = (Token*)malloc(sizeof(Token));
    token->type = type;
    token->value = strdup(value);
    return token;
}

void destroy_token(Token* token) {
    free(token);
}
/*typedef struct Node {
    NodeType type;
    char* value;
    struct Node** children;
    size_t child_count;
} Node;*/
Token* next_token(Lexer* lexer) {
    while (isspace(peek(lexer))) advance(lexer);

    if (isdigit(peek(lexer))) {
        size_t start = lexer->position;
        while (isdigit(peek(lexer))) advance(lexer);
        char* number = strndup(&lexer->source[start], lexer->position - start);
        return create_token(TOKEN_LITERAL, number);
    }

    if (isalpha(peek(lexer)) || peek(lexer) == '&') {
        size_t start = lexer->position;
        while (isalnum(peek(lexer)) || peek(lexer) == '_') advance(lexer);
        char* identifier = strndup(&lexer->source[start], lexer->position - start);
        return create_token(TOKEN_IDENTIFIER, identifier);
    }

    if (peek(lexer) == '\"') {
        advance(lexer);  // skip opening quote
        size_t start = lexer->position;
        while (peek(lexer) != '\"'){
		if (peek(lexer) == '\0'){
			printf("Error at line %d: Expected closing double quote, but found none.\n", lexer->line);
			return create_token(TOKEN_ERROR, "");
			// advance(lexer);
		}else{
			advance(lexer);
		}
	}
        char* string = strndup(&lexer->source[start], lexer->position - start);
        advance(lexer);  // skip closing quote
        return create_token(TOKEN_LITERAL, string);
    }
    char c = advance(lexer);
    if (c == '{' || c == '}' || c == '(' || c == ')') {
        char punct[2] = {c, '\0'};
        return create_token(TOKEN_PUNCTUATION, punct);
    }

    if (c == '\0') {
        return create_token(TOKEN_EOF, "");
    }
    if (c == '\n'){
	lexer->line++;
	return create_token(TOKEN_NEWLINE, "");
    }
	size_t start = lexer->position;
	while (peek(lexer) != '\0') advance(lexer);
        char* string = strndup(&lexer->source[start], lexer->position - start);
	printf("Str: %s", string);
	return create_token(TOKEN_KEYWORD, string);

    // Add other token types like operators as needed
}
/*typedef enum {
    NODE_PROGRAM,
    NODE_SECTION,
    NODE_ASSIGNMENT,
    NODE_PRINT,
    NODE_CONDITION,
    NODE_LOAD,
    NODE_BOOT,
    NODE_IDENTIFIER,
    NODE_LITERAL
} NodeType;

/*typedef struct Node {
    NodeType type;
    char* value;
    struct Node** children;
    size_t child_count;
} Node;*/

/*typedef struct Node {
    NodeType type;
    char* value;
    struct Node** children;
    size_t child_count;
} Node;
*/
// Adding more detailed node types for complex constructs
typedef enum {
    NODE_PROGRAM,
    NODE_SECTION,
    NODE_ASSIGNMENT,
    NODE_PRINT,
    NODE_CONDITION,
    NODE_LOAD,
    NODE_BOOT,
    NODE_FUNCTION_CALL,
    NODE_VARIABLE,
    NODE_LITERAL,
    NODE_OPERATOR,
    NODE_ERROR
} NodeType;
typedef struct Node {
    NodeType type;
    char* value;
    struct Node** children;
    size_t child_count;
} Node;
Node* create_node(NodeType type, char* value) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->type = type;
    node->value = value ? strdup(value) : NULL;
    node->children = NULL;
    node->child_count = 0;
    return node;
}

void destroy_node(Node* node) {
    if (node->value) free(node->value);
    for (size_t i = 0; i < node->child_count; ++i) {
        destroy_node(node->children[i]);
    }
    free(node->children);
    free(node);
}

void add_child(Node* parent, Node* child) {
    parent->children = (Node**)realloc(parent->children, sizeof(Node*) * (parent->child_count + 1));
    parent->children[parent->child_count++] = child;
}

Node* parse_program(Lexer* lexer);

Node* parse_section(Lexer* lexer) {
    Token* token = next_token(lexer);
    Node* section_node = create_node(NODE_SECTION, "section");

    while (strcmp(token->value, "}") != 0) {
        if (strcmp(token->value, "Class") == 0) {
            Node* assignment_node = create_node(NODE_ASSIGNMENT, "assignment");
            add_child(section_node, assignment_node);
            // Parse assignment...
        }
        token = next_token(lexer);
    }
    destroy_token(token);
    return section_node;
}

/*Node* parse_program(Lexer* lexer) {
    Node* program_node = create_node(NODE_PROGRAM, "program");
    Token* token;

    while ((token = next_token(lexer))->type != TOKEN_EOF) {
        if (strcmp(token->value, "section") == 0) {
            add_child(program_node, parse_section(lexer));
        } else if (strcmp(token->value, "PRINT") == 0) {
            Node* print_node = create_node(NODE_PRINT, "print");
            add_child(program_node, print_node);
            // Parse PRINT arguments...
        } else if (strcmp(token->value, "LOAD") == 0) {
            Node* load_node = create_node(NODE_LOAD, "load");
            add_child(program_node, load_node);
            // Parse LOAD address...
        } else if (strcmp(token->value, "BOOT") == 0) {
            Node* boot_node = create_node(NODE_BOOT, "boot");
            add_child(program_node, boot_node);
            // Parse BOOT address and file...
        }
        destroy_token(token);
    }

    destroy_token(token);
    return program_node;
}*/

/*void print_ast(Node* node, int depth) {
    for (int i = 0; i < depth; ++i) printf("  ");
    printf("%s\n", node->value ? node->value : "(no value)");
    for (size_t i = 0; i < node->child_count; ++i) {
        print_ast(node->children[i], depth + 1);
    }
}*/
Node* parse_expression(Lexer* lexer) {
    Token* token = next_token(lexer);

    if (token->type == TOKEN_IDENTIFIER) {
        if (token->value[0] == '&') {
            // Handle variable reference
            Node* var_node = create_node(NODE_VARIABLE, token->value + 1);
            destroy_token(token);
            return var_node;
        } else {
            // Handle function call or other identifiers
            Node* func_node = create_node(NODE_FUNCTION_CALL, token->value);
            destroy_token(token);

            Token* next_tokens = next_token(lexer);
            if (next_tokens->type == TOKEN_PUNCTUATION && strcmp(next_tokens->value, "(") == 0) {
                // Parse function call arguments
                while ((next_tokens = next_token(lexer))->type != TOKEN_PUNCTUATION || strcmp(next_tokens->value, ")") != 0) {
                    Node* arg = parse_expression(lexer);
                    add_child(func_node, arg);
                }
            }
            destroy_token(next_tokens);
            return func_node;
        }
    } else if (token->type == TOKEN_LITERAL) {
        // Handle literals
        Node* literal_node = create_node(NODE_LITERAL, token->value);
        destroy_token(token);
        return literal_node;
    }

    destroy_token(token);
    return NULL;
}

Node* parse_condition(Lexer* lexer) {
    Token* token = next_token(lexer);
    if (strcmp(token->value, "if") == 0) {
        destroy_token(token);

        Node* condition_node = create_node(NODE_CONDITION, "condition");

        // Parse condition expression
        Node* expression = parse_expression(lexer);
        add_child(condition_node, expression);

        Token* next_tokens = next_token(lexer);
        if (next_tokens->type == TOKEN_PUNCTUATION && strcmp(next_tokens->value, "{") == 0) {
            // Parse the block of statements inside the condition
            destroy_token(next_tokens);
            while ((next_tokens = next_token(lexer))->type != TOKEN_PUNCTUATION || strcmp(next_tokens->value, "}") != 0) {
                Node* stmt = parse_program(lexer);
                add_child(condition_node, stmt);
            }
            destroy_token(next_tokens);
        }

        return condition_node;
    }
    return NULL;
}

Node* parse_program(Lexer* lexer) {
    Node* program_node = create_node(NODE_PROGRAM, "program");
    Node* error_node = create_node(NODE_ERROR, "error");
    Token* token;
    printf("Parse");
    while ((token = next_token(lexer)) && token->type != TOKEN_EOF) {
	printf("Token: %s", token->value);
        if (strcmp(token->value, "section") == 0) {
            add_child(program_node, parse_section(lexer));
        } else if (strcmp(token->value, "PRINT") == 0) {
            Node* print_node = create_node(NODE_PRINT, "print");
            add_child(program_node, print_node);
            // Parse PRINT arguments
            Node* expression = parse_expression(lexer);
            add_child(print_node, expression);
        } else if (strcmp(token->value, "LOAD") == 0) {
            Node* load_node = create_node(NODE_LOAD, "load");
            add_child(program_node, load_node);
            // Parse LOAD address
            Node* address = parse_expression(lexer);
            add_child(load_node, address);
        } else if (strcmp(token->value, "BOOT") == 0) {
            Node* boot_node = create_node(NODE_BOOT, "boot");
            add_child(program_node, boot_node);
            // Parse BOOT address and file
            Node* address = parse_expression(lexer);
            add_child(boot_node, address);
            Token* lock_file_token = next_token(lexer);
            if (lock_file_token->type == TOKEN_IDENTIFIER) {
                Node* lock_file_node = create_node(NODE_LITERAL, lock_file_token->value);
                add_child(boot_node, lock_file_node);
            }
            destroy_token(lock_file_token);
        } else if (strcmp(token->value, "if") == 0) {
            add_child(program_node, parse_condition(lexer));
        } else if (token->type == TOKEN_ERROR){
	    Node* error = create_node(NODE_ERROR, token->value);
	    add_child(error_node, error);
	}
        destroy_token(token);
    }

    destroy_token(token);
    return program_node;
}
void analyze_ast(Node* node) {
    // Semantic checks and optimizations can be implemented here
    if (node->type == NODE_ERROR){
	error++;
    }else if (node->type == NODE_ASSIGNMENT) {
        printf("Analyzing assignment to %s\n", node->children[0]->value);
    }
    for (size_t i = 0; i < node->child_count; ++i) {
        analyze_ast(node->children[i]);
    }
}

void generate_code(Node* node) {
    // Code generation logic
    printf("%s", (char *)node);
    if (error > 0){
	printf("Generated %d errors. Unbelievable!", error);
	exit(1);
    }

    if (node->type == NODE_PRINT) {
        printf("Generated code to print: %s\n", node->children[0]->value);
    } else if (node->type == NODE_LOAD) {
        printf("Generated code to load address: %s\n", node->children[0]->value);
    } else if (node->type == NODE_BOOT) {
        printf("Generated code to boot from address: %s with lock file %s\n", node->children[0]->value, node->children[1]->value);
    } else{
	printf("Blank");
    }
    for (size_t i = 0; i < node->child_count; ++i) {
        generate_code(node->children[i]);
    }
}

int main() {
    char* code = 
        "section var{\n"
        "    Class(PGM) program_info eq @pi\n"
        "}\n"
        "PRINT <class_to_strdata>(&program_info)\n"
        "if (&program_info:compiler_vers lt 1){\n"
        "    PRINT (\"compiler version too low\")\n"
        "}\n"
        "LOAD [1e00]\n"
        "BOOT [1f00] /[VAR]/ZBoot\n";

    Lexer* lexer = create_lexer(code);
    Node* ast = parse_program(lexer);

    // Perform semantic analysis
    analyze_ast(ast);

    // Generate code or interpret the AST
    generate_code(ast);

    // Clean up
    destroy_node(ast);
    destroy_lexer(lexer);

    return 0;
}
/*int main() {
    char* code = 
        "@ps #point to start\n"
        "section var{\n"
        "    Class(PGM) program_info eq @pi\n"
        "}\n"
        "PRINT <class_to_strdata>(&program_info)\n"
        "if (&program_info:compiler_vers lt 1){\n"
        "    PRINT (\"compiler version too low\")\n"
        "}\n"
        "LOAD [1e00]\n"
        "BOOT [1f00] /[VAR]/ZBoot\n";

    Lexer* lexer = create_lexer(code);
    Node* ast = parse_program(lexer);
    print_ast(ast, 0);

    destroy_node(ast);
    destroy_lexer(lexer);
    return 0;
}
*/
