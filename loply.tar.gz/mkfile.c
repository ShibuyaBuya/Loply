#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
int main(){
	FILE *file = fopen("zrun.bin", "wb");
    if (file) {
        char *buffer = (char *)calloc((10 * 1024 * 1024), 1);
        fwrite(buffer, (10 * 1024 * 1024), 1, file);
        free(buffer);
        fclose(file);
    } else {
        perror("Error creating EEPROM file");
        return 1;
    }
    return 0;
}
